import time

def solve(D: int, A: str) -> int:
    return D / 0


def main():
    D = int(input())
    A = input()
    print(solve(D, A))


if __name__ == '__main__':
    main()
